import { BadRequestException, Injectable } from "@nestjs/common";
import { Tag } from "@prisma/client";
import { ContextualGraphqlRequest, UseCase } from "src";
import SaveTagDto from "src/Api/Dto/SaveTagDto";
import TagRepository from "src/Api/Repository/TagRepository";

@Injectable()
export default class CreateTagUseCase
  implements UseCase<Promise<Tag>, [dto: SaveTagDto]>
{
  constructor(private readonly tageRepository: TagRepository) {}
  async handle(context: ContextualGraphqlRequest, dto: SaveTagDto) {
    try {
      return await this.tageRepository.save(dto);
    } catch (error) {
      throw new BadRequestException("cannot create tag", error.message);
    }
  }
}
