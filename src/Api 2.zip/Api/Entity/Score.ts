import { ObjectType, Field, Int, } from '@nestjs/graphql';
import { Level } from '@prisma/client';

@ObjectType()
export class Score {
  @Field(() => Int)
  id: number;

  @Field(() => Int)
  userId: number;

  @Field(() => Int)
  time: number;

  @Field()
  createdAt: Date;

  @Field(() => Level) 
  level: Level;
}
