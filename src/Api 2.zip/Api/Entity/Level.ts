import { registerEnumType } from "@nestjs/graphql";

export enum Level {
    EASY = 'EASY',
    MEDIUM = 'MEDIUM',
    HARD = 'HARD',
  }
  
  
  registerEnumType(Level, {
    name: 'Level',
  });
  